# /// script
# dependencies = [
#   "pygame-ce",
#   "pygame_widgets",
# ]
# ///
import asyncio
import pygame_widgets
import pygame
from pygame_widgets.slider import Slider
from pygame_widgets.textbox import TextBox
from pygame_widgets.button import Button
import math
import random

pygame.init()
width = 1280
height = 720
screen = pygame.display.set_mode((width, height))
clock = pygame.time.Clock()


running = True
menu = True
show_ans1 = False
show_ans2 = False
show_ans3 = False
problem_set = 1

inertia_slider = Slider(screen, 70, 60, 100, 30, min=0, max=1, step=1)
inertia_output = TextBox(screen, 200, 50, 50, 50, fontSize=30)
inertia_output.disable()

friction_slider = Slider(screen, 70, 160, 100, 30, min=0, max=1, step=1)
friction_output = TextBox(screen, 200, 150, 50, 50, fontSize=30)
friction_output.disable()

font = pygame.font.SysFont('Arial', 14)
answer1 = Button(screen, 900, 150, 170, 40, text = 'Show/Hide Answer', fontSize = 14, onClick = lambda: change_ans1())
answer2 = Button(screen, 900, 250, 170, 40, text = 'Show/Hide Answer', fontSize = 14, onClick = lambda: change_ans2())
answer3 = Button(screen, 900, 350, 170, 40, text = 'Show/Hide Answer', fontSize = 14, onClick = lambda: change_ans3())

random_buttom = Button(screen, 1050, 550, 200, 50, text = 'New problem?', fontSize = 14, onClick = lambda: randomize())
run = Button(screen, 1050, 490, 200, 50, text = 'Start/Stop', fontSize = 14, onClick = lambda: change_menustatus())
prob_set_button = Button(screen, 1050, 650, 200, 50, text = 'Change Problem Set', fontSize = 14, onClick = lambda: change_probset())

prob6 = Button(screen, 25, 650, 200, 50, text = "Universal Gravitation", fontSize = 14, onClick = lambda: changeto_prob(6))
prob7 = Button(screen, 230, 650, 200, 50, text = "2 Tensions", fontSize = 14, onClick = lambda: changeto_prob(7))
prob8 = Button(screen, 435, 650, 200, 50, text = "Racecar", fontSize = 14, onClick = lambda: changeto_prob(8))
prob9 = Button(screen, 845, 650, 200, 50, text = "Bonus", fontSize = 14, onClick = lambda: changeto_prob(9))
prob10 = Button(screen, 640, 650, 200, 50, text = "Resistive Forces", fontSize = 14, onClick = lambda: changeto_prob(10))
prob6.hide()
prob7.hide()
prob8.hide()
prob9.hide()
prob10.hide()
prob1 = Button(screen, 25, 650, 200, 50, text = "Atwood Machine", fontSize = 14, onClick = lambda: changeto_prob(1))
prob2 = Button(screen, 230, 650, 200, 50, text = "Atwood on Incline", fontSize = 14, onClick = lambda: changeto_prob(2))
prob3 = Button(screen, 435, 650, 200, 50, text = "Ball on Incline", fontSize = 14, onClick = lambda: changeto_prob(3))
prob4 = Button(screen, 640, 650, 200, 50, text = "Projectile Motion", fontSize = 14, onClick = lambda: changeto_prob(4))
prob5 = Button(screen, 845, 650, 200, 50, text = "Collision", fontSize = 14, onClick = lambda: changeto_prob(5))



problem_type = 1
mass1, mass2, mass_pulley, radius_pulley, tvar, hvar, Vvar, theta, Ustatic, Ukinetic, inertia_constant, initial_velocity, central_mass, radius1, radius2, tension1, tension2, theta1, theta2, length, height, b_constant, tfall = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
gravity, uni_constant = 9.8, 6.67 * pow(10, -11)


def change_menustatus():
    global menu
    if menu == True:
        menu = False
    else:
        menu = True

def change_probset():
    global problem_set
    if problem_set == 1:
        problem_set = 2
        prob1.hide()
        prob2.hide()
        prob3.hide()
        prob4.hide()
        prob5.hide()
        prob6.show()
        prob7.show()
        prob8.show()
        prob9.show()
        prob10.show()
    else: 
        problem_set = 1
        prob1.show()
        prob2.show()
        prob3.show()
        prob4.show()
        prob5.show()
        prob6.hide()
        prob7.hide()
        prob8.hide()
        prob9.hide()
        prob10.hide()
        
def changeto_prob(x):
    global problem_type
    problem_type = x
    if x == 10:
        answer3.hide()
    else:
        answer3.show()
    randomize()


def change_ans1():
    global show_ans1
    if show_ans1 == False:
        show_ans1 = True
    else:
        show_ans1 = False

def change_ans2():
    global show_ans2
    if show_ans2 == False:
        show_ans2 = True
    else:
        show_ans2 = False

def change_ans3():
    global show_ans3
    if show_ans3 == False:
        show_ans3 = True
    else:
        show_ans3 = False

def randomize():
    global mass1, mass2, mass_pulley, radius_pulley, tvar, hvar, Vvar, displacement, show_ans1, show_ans2, show_ans3, theta, problem_type, menu, Ustatic, Ukinetic, inertia_constant, initial_velocity, central_mass, radius1, radius2, tension1, tension2, theta1, theta2, length, height, b_constant, tfall
    menu = True
    if problem_type == 5:
        mass1 = float(random.randint(10, 30))
        mass2 = float(random.randint(40, 60))
    elif problem_type == 6:
        mass1 = float(random.randint(3, 10))
        mass2 = float(random.randint(3, 10))
        radius1 = float(random.randint(100, 150))
        radius2 = float(random.randint(200, 250))
        central_mass = float(random.randint(6000, 10000))
    elif problem_type == 8:
        radius1 = float(random.randint(150, 200))
    elif problem_type == 9:
        mass1 = float(random.randint(20, 30))
        mass2 = float(random.randint(10, 20))
    else:
        mass1 = float(random.randint(25, 100))
        mass2 = float(random.randint(25, 100))
    #mass1 = 25.0
    #mass2 = 100.0
    if problem_type == 7:
        tension1 = float(random.randint(25, 100))
        tension2 = float(random.randint(25, 100))
        theta1 = float(random.randint(15, 60))
        theta2 = float(random.randint(75, 85))
        length = float(random.randint(20, 30))
    elif problem_type == 9:
        theta1 = float(random.randint(5, 15))
        theta2 = float(random.randint(4, 10))
        length = float(random.randint(150, 300))
    mass_pulley = float(random.randint(10, 100))
    radius_pulley = float(random.randint(5, 25))
    if problem_type == 4 or problem_type == 5:
        if problem_type == 4:
            initial_velocity = float(random.randint(50, 80))
        else:
            initial_velocity = float(random.randint(30, 60))
    else:
        initial_velocity = 0.0
        tvar = round(random.uniform(3.0, 5.0), 1)
    #tvar = 5.0
    displacement = 0.0
    if problem_type == 1:
        theta = 0.0
    elif problem_type == 2:
        theta = float(random.randint(30, 60))
    elif problem_type == 3:
        theta = float(random.randint(10, 30))
    elif problem_type == 4:
        theta = float(random.randint(30, 60))
    elif problem_type == 8:
        theta = float(random.randint(5, 20))
    Ustatic = round(random.uniform(0.5, 0.8), 2)
    Ukinetic = round(Ustatic * random.uniform(0.5, 0.8), 2)  
    tfall = round(random.uniform(1.0, 3.0), 1)
    b_constant = round(mass1 * random.uniform(0.05, 0.2), 2)
    height = float(random.randint(300, 500))
    if problem_type == 10:
        mass1 = round(math.sqrt((height * b_constant**2) / (4 * gravity)), 2)
    if problem_type == 3:
        x = random.randint(0,3)
        vals = [1.0, .5, .4, 2.0/3]
        inertia_constant = vals[x]
    show_ans1 = False
    show_ans2 = False
    show_ans3 = False

def text_print():
    if problem_type == 1 or problem_type == 2:
        text_surf = font.render('Inertia(1/2MR^2)?', True, (0, 0, 0))
        screen.blit(text_surf, (50, 20))
    if problem_type == 2:
        text_surf = font.render('Friction?', True, (0, 0, 0))
        screen.blit(text_surf, (50, 110))
    if problem_type < 7:
        if problem_type != 6:
            text_surf = font.render('Mass1(kg): ' + str(mass1), True, 'red')
        else:
            text_surf = font.render('Central Mass(kg): ' + str(central_mass), True, 'black')
        if problem_type == 4:
            screen.blit(text_surf, (50, 480))
        elif problem_type == 5:
            screen.blit(text_surf, (50, 430))
        elif problem_type == 6:
            screen.blit(text_surf, (50, 30))
        else:
            screen.blit(text_surf, (50, 230))
    if problem_type == 1 or problem_type == 2 or problem_type == 5:
        text_surf = font.render('Mass2(kg): ' + str(mass2), True, 'blue')
        if problem_type == 5:
            screen.blit(text_surf, (50, 480))
        else:
            screen.blit(text_surf, (50, 280))
    if (problem_type == 1 or problem_type == 2) and inertia_slider.getValue() == 1:
        text_surf = font.render('Mass of Pulley(kg): ' + str(mass_pulley), True, (0, 0, 0))
        screen.blit(text_surf, (50, 330))
        text_surf = font.render('Radius of Pulley(m): ' + str(radius_pulley), True, (0, 0, 0))
        screen.blit(text_surf, (50, 380))
    if problem_type < 4:
        text_surf = font.render('Time(s): ' + str(tvar), True, (0, 0, 0))
        if problem_type == 3 or inertia_slider.getValue() == 0:
            screen.blit(text_surf, (50, 330))
        else:
            screen.blit(text_surf, (50, 430))
    if problem_type == 2:
        text_surf = font.render('Theta(degrees): ' + str(theta), True, (0, 0, 0))
        if inertia_slider.getValue() == 0:
            screen.blit(text_surf, (50, 380))
        else:
            screen.blit(text_surf, (50, 480))
        if friction_slider.getValue() == 1:
            if inertia_slider.getValue() == 0:
                text_surf = font.render('Static coeffecient: ' + str(Ustatic), True, (0, 0, 0))
                screen.blit(text_surf, (50, 430))
                text_surf = font.render('Kinetic coeffecient: ' + str(Ukinetic), True, (0, 0, 0))
                screen.blit(text_surf, (50, 480))
            else:
                text_surf = font.render('Static coeffecient: ' + str(Ustatic), True, (0, 0, 0))
                screen.blit(text_surf, (50, 530))
                text_surf = font.render('Kinetic coeffecient: ' + str(Ukinetic), True, (0, 0, 0))
                screen.blit(text_surf, (50, 580))
    elif problem_type == 3:
        text_surf = font.render('Radius(m): ' + str(radius_pulley), True, (0, 0, 0))
        screen.blit(text_surf, (50, 280))
        text_surf = font.render('Theta(degrees): ' + str(theta), True, (0, 0, 0))
        screen.blit(text_surf, (50, 380))
        if inertia_constant == 1.0:
            text_surf = font.render('Shape: Thin Hoop', True, (0, 0, 0))
            screen.blit(text_surf, (50, 430))
            text_surf = font.render('Inertia(kgm^2): MR^2', True, (0, 0, 0))
            screen.blit(text_surf, (50, 480))
        elif inertia_constant == .5:
            text_surf = font.render('Shape: Solid Cylinder', True, (0, 0, 0))
            screen.blit(text_surf, (50, 430))
            text_surf = font.render('Inertia(kgm^2): (1/2)MR^2', True, (0, 0, 0))
            screen.blit(text_surf, (50, 480))
        elif inertia_constant == .4:
            text_surf = font.render('Shape: Uniform Sphere', True, (0, 0, 0))
            screen.blit(text_surf, (50, 430))
            text_surf = font.render('Inertia(kgm^2): (2/5)MR^2', True, (0, 0, 0))
            screen.blit(text_surf, (50, 480))
        else:
            text_surf = font.render('Shape: Hollow Sphere', True, (0, 0, 0))
            screen.blit(text_surf, (50, 430))
            text_surf = font.render('Inertia(kgm^2): (2/3)MR^2', True, (0, 0, 0))
            screen.blit(text_surf, (50, 480))
    elif problem_type == 4:
        text_surf = font.render('Theta(degrees): ' + str(theta), True, (0, 0, 0))
        screen.blit(text_surf, (50, 530))
        text_surf = font.render('Initial Velocity(m/s): ' + str(initial_velocity), True, (0, 0, 0))
        screen.blit(text_surf, (50, 580))
    elif problem_type == 5:
        text_surf = font.render('Kinetic coeffecient: ' + str(Ukinetic), True, (0, 0, 0))
        screen.blit(text_surf, (50, 530))
        text_surf = font.render('Initial Velocity of Mass1(m/s): ' + str(initial_velocity), True, (0, 0, 0))
        screen.blit(text_surf, (50, 580))
    elif problem_type == 6:
        text_surf = font.render('Mass1(kg): ' + str(mass1), True, 'red')
        screen.blit(text_surf, (50, 80))
        text_surf = font.render('Radius of Mass1(m): ' + str(radius1), True, 'red')
        screen.blit(text_surf, (50, 130))
        text_surf = font.render('Mass2(kg): ' + str(mass2), True, 'blue')
        screen.blit(text_surf, (50, 180))
        text_surf = font.render('Radius of Mass2(m): ' + str(radius2), True, 'blue')
        screen.blit(text_surf, (50, 230))
    elif problem_type == 7:
        text_surf = font.render('Tension1(N): ' + str(tension1), True, 'red')
        screen.blit(text_surf, (50, 30))
        text_surf = font.render('Theta1(degrees): ' + str(theta1), True, 'red')
        screen.blit(text_surf, (50, 80))
        text_surf = font.render('Tension2(N): ' + str(tension2), True, 'blue')
        screen.blit(text_surf, (50, 130))
        text_surf = font.render('Theta2(degrees): ' + str(theta2), True, 'blue')
        screen.blit(text_surf, (50, 180))
        text_surf = font.render('Length of String2(m): ' + str(length), True, 'blue')
        screen.blit(text_surf, (50, 230))
    elif problem_type == 8:
        text_surf = font.render('Radius(m): ' + str(radius1), True, 'black')
        screen.blit(text_surf, (50, 30))
        text_surf = font.render('Static coeffecient: ' + str(Ustatic), True, 'black')
        screen.blit(text_surf, (50, 80))
        text_surf = font.render('For Question 3, assume', True, 'red')
        screen.blit(text_surf, (50, 130))
        text_surf = font.render('-Frictionless surface', True, 'red')
        screen.blit(text_surf, (50, 180))
        text_surf = font.render('-Banked curve of ' + str(theta) + '°', True, 'red')
        screen.blit(text_surf, (50, 230))
    elif problem_type == 9:
        text_surf = font.render('Mass1(kg): ' + str(mass1), True, 'red')
        screen.blit(text_surf, (50, 30))
        text_surf = font.render('Theta1(degrees): ' + str(theta1), True, 'red')
        screen.blit(text_surf, (50, 80))
        text_surf = font.render('Mass2(kg): ' + str(mass2), True, 'blue')
        screen.blit(text_surf, (50, 130))
        text_surf = font.render('Theta2(degrees): ' + str(theta2), True, 'blue')
        screen.blit(text_surf, (50, 180))
        text_surf = font.render('Length of String(m): ' + str(length), True, 'black')
        screen.blit(text_surf, (50, 230))
    elif problem_type == 10:
        text_surf = font.render('Mass1(kg): ' + str(mass1), True, 'red')
        screen.blit(text_surf, (50, 30))
        text_surf = font.render('Coefficient b(kg/s): ' + str(b_constant), True, 'red')
        screen.blit(text_surf, (50, 80))
        text_surf = font.render('Initial Height(m): ' + str(height), True, 'blue')
        screen.blit(text_surf, (50, 130))


    text_surf = font.render('Questions:', True, 'black')
    screen.blit(text_surf, (900, 50))
    if problem_type <= 3:
        text_surf = font.render('1. What is the magnitude of the', True, 'black')
        screen.blit(text_surf, (900, 100))
        text_surf = font.render('linear acceleration of the system?', True, 'black')
        screen.blit(text_surf, (900, 125))
        if show_ans1 == True:
            text_surf = font.render(str(abs(round(acceleration, 2))) + 'm/s^2', True, 'red')
            screen.blit(text_surf, (1100, 165))
    elif problem_type == 4:
        text_surf = font.render('1. What is maximum height of ', True, 'black')
        screen.blit(text_surf, (900, 100))
        text_surf = font.render('the projectile?', True, 'black')
        screen.blit(text_surf, (900, 125))
        if show_ans1 == True:
            text_surf = font.render(str(abs(round(pow(initial_velocity * math.sin(math.radians(theta)), 2) / (2 * gravity), 2))) + 'm', True, 'red')
            screen.blit(text_surf, (1100, 165))
    elif problem_type == 5:
        text_surf = font.render('1. What is the velocity of the', True, 'black')
        screen.blit(text_surf, (900, 100))
        text_surf = font.render('blue mass after the collision?', True, 'black')
        screen.blit(text_surf, (900, 125))
        if show_ans1 == True:
            text_surf = font.render(str(abs(round(mass1 * initial_velocity / mass2, 2))) + 'm/s', True, 'red')
            screen.blit(text_surf, (1100, 165))
    elif problem_type == 6:
        text_surf = font.render('1. What is the force of gravity of', True, 'black')
        screen.blit(text_surf, (900, 100))
        text_surf = font.render('the central mass on mass1?', True, 'black')
        screen.blit(text_surf, (900, 125))
        if show_ans1 == True:
            text_surf = font.render(f"{(uni_constant * central_mass * mass1) / pow(radius1, 2):.5e}N", True, 'red')
            screen.blit(text_surf, (1100, 165))
    elif problem_type == 7:
        text_surf = font.render('1. What is the mass of', True, 'black')
        screen.blit(text_surf, (900, 100))
        text_surf = font.render('the hanging block initially?', True, 'black')
        screen.blit(text_surf, (900, 125))
        if show_ans1 == True:
            text_surf = font.render(str(round((tension1 * math.sin(math.radians(theta1)) + tension2 * math.sin(math.radians(theta2))) / gravity, 2)) + 'kg', True, 'red')
            screen.blit(text_surf, (1100, 165))
    elif problem_type == 8:
        text_surf = font.render('1. What is the max velocity that', True, 'black')
        screen.blit(text_surf, (900, 100))
        text_surf = font.render('still keeps the car on the track?', True, 'black')
        screen.blit(text_surf, (900, 125))
        if show_ans1 == True:
            text_surf = font.render(str(round(math.sqrt(Ustatic * radius1 * gravity), 2)) + 'm/s', True, 'red')
            screen.blit(text_surf, (1100, 165))
    elif problem_type == 9:
        text_surf = font.render('1. What is the max velocity of', True, 'black')
        screen.blit(text_surf, (900, 100))
        text_surf = font.render('the pendulum?', True, 'black')
        screen.blit(text_surf, (900, 125))
        if show_ans1 == True:
            text_surf = font.render(str(round(math.sqrt(2 * gravity * length * (1 - math.cos(math.radians(theta1)))), 2)) + 'm/s', True, 'red')
            screen.blit(text_surf, (1100, 165))
    else:
        text_surf = font.render('1. What is the terminal velocity', True, 'black')
        screen.blit(text_surf, (900, 100))
        text_surf = font.render('of the mass?', True, 'black')
        screen.blit(text_surf, (900, 125))
        if show_ans1 == True:
            text_surf = font.render(str(round(mass1 * gravity / b_constant, 2)) + 'm/s', True, 'red')
            screen.blit(text_surf, (1100, 165))

    if problem_type == 1:
        text_surf = font.render('2. What is the change in', True, 'black')
        screen.blit(text_surf, (900, 200))
        text_surf = font.render('height of masses?', True, 'black')
        screen.blit(text_surf, (900, 225))
        if show_ans2 == True:
            text_surf = font.render(str(abs(round(hvar, 2))) + 'm', True, 'red')
            screen.blit(text_surf, (1100, 265))
        text_surf = font.render('3. What the magnitude of the', True, 'black')
        screen.blit(text_surf, (900, 300))
        text_surf = font.render('final velocities of the masses?', True, 'black')
        screen.blit(text_surf, (900, 325))
        if show_ans3 == True:
            text_surf = font.render(str(abs(round(Vvar, 2))) + 'm/s', True, 'red')
            screen.blit(text_surf, (1100, 365))
    elif problem_type == 2:
        text_surf = font.render('2. What is the displacement', True, 'black')
        screen.blit(text_surf, (900, 200))
        text_surf = font.render('of the masses?', True, 'black')
        screen.blit(text_surf, (900, 225))
        if show_ans2 == True:
            text_surf = font.render(str(abs(round(hvar, 2))) + 'm', True, 'red')
            screen.blit(text_surf, (1100, 265))
        text_surf = font.render('3. What the magnitude of the', True, 'black')
        screen.blit(text_surf, (900, 300))
        text_surf = font.render('final velocities of the masses?', True, 'black')
        screen.blit(text_surf, (900, 325))
        if show_ans3 == True:
            text_surf = font.render(str(abs(round(Vvar, 2))) + 'm/s', True, 'red')
            screen.blit(text_surf, (1100, 365))
    elif problem_type == 3:
        text_surf = font.render('2. What is the force of', True, 'black')
        screen.blit(text_surf, (900, 200))
        text_surf = font.render('static friction?', True, 'black')
        screen.blit(text_surf, (900, 225))
        if show_ans2 == True:
            text_surf = font.render(str(abs(round(mass1 * acceleration - mass1 * gravity * math.sin(math.radians(theta)), 2))) + 'N', True, 'red')
            screen.blit(text_surf, (1100, 265))
        text_surf = font.render('3. What the magnitude of the', True, 'black')
        screen.blit(text_surf, (900, 300))
        text_surf = font.render('final velocity of the mass?', True, 'black')
        screen.blit(text_surf, (900, 325))
        if show_ans3 == True:
            text_surf = font.render(str(abs(round(Vvar, 2))) + 'm/s', True, 'red')
            screen.blit(text_surf, (1100, 365))
    elif problem_type == 4:
        text_surf = font.render('2. What is the total flight', True, 'black')
        screen.blit(text_surf, (900, 200))
        text_surf = font.render('time of the projectile?', True, 'black')
        screen.blit(text_surf, (900, 225))
        if show_ans2 == True:
            text_surf = font.render(str(abs(round(2 * initial_velocity * math.sin(math.radians(theta)) / gravity, 2))) + 's', True, 'red')
            screen.blit(text_surf, (1100, 265))
        text_surf = font.render('3. What is the horizontal', True, 'black')
        screen.blit(text_surf, (900, 300))
        text_surf = font.render('displacement of the projectile?', True, 'black')
        screen.blit(text_surf, (900, 325))
        if show_ans3 == True:
            text_surf = font.render(str(abs(round(initial_velocity * math.cos(math.radians(theta)) * ((2 * initial_velocity * math.sin(math.radians(theta))) / gravity), 2))) + 'm', True, 'red')
            screen.blit(text_surf, (1100, 365))
    elif problem_type == 5:
        text_surf = font.render('2. What is the displacement', True, 'black')
        screen.blit(text_surf, (900, 200))
        text_surf = font.render('of the blue mass?', True, 'black')
        screen.blit(text_surf, (900, 225))
        if show_ans2 == True:
            text_surf = font.render(str(abs(round((1 / (2 * Ukinetic * gravity)) * pow((mass1 * initial_velocity) / mass2, 2), 2))) + 'm', True, 'red')
            screen.blit(text_surf, (1100, 265))
        text_surf = font.render('3. Find displacement assuming', True, 'black')
        screen.blit(text_surf, (900, 300))
        text_surf = font.render('a perfeclty inelastic collision.', True, 'black')
        screen.blit(text_surf, (900, 325))
        if show_ans3 == True:
            text_surf = font.render(str(abs(round((1 / (2 * Ukinetic * gravity)) * pow((mass1 * initial_velocity) / (mass1 + mass2), 2), 2))) + 'm', True, 'red')
            screen.blit(text_surf, (1100, 365))
    elif problem_type == 6:
        text_surf = font.render('2. What is the ratio of the', True, 'black')
        screen.blit(text_surf, (900, 200))
        text_surf = font.render('velocity2 / velocity1?', True, 'black')
        screen.blit(text_surf, (900, 225))
        if show_ans2 == True:
            text_surf = font.render(str(abs(round(math.sqrt(radius1 / radius2), 2))), True, 'red')
            screen.blit(text_surf, (1100, 265))
        text_surf = font.render('3. At their furthest distances', True, 'black')
        screen.blit(text_surf, (900, 300))
        text_surf = font.render('apart, what is Fg of m1 on m2?', True, 'black')
        screen.blit(text_surf, (900, 325))
        if show_ans3 == True:
            text_surf = font.render(f"{(uni_constant * mass1 * mass2) / pow(radius1 + radius2, 2):.5e}N", True, 'red')
            screen.blit(text_surf, (1100, 365))
    elif problem_type == 7:
        text_surf = font.render('2. What is the max potential', True, 'black')
        screen.blit(text_surf, (900, 200))
        text_surf = font.render('energy of the block?', True, 'black')
        screen.blit(text_surf, (900, 225))
        if show_ans2 == True:
            text_surf = font.render(str(round((tension1 * math.sin(math.radians(theta1)) + tension2 * math.sin(math.radians(theta2))) * (length - length * math.sin(math.radians(theta2))), 2)) + 'J', True, 'red')
            screen.blit(text_surf, (1100, 265))
        text_surf = font.render('3. What is the max velocity', True, 'black')
        screen.blit(text_surf, (900, 300))
        text_surf = font.render('of the block?', True, 'black')
        screen.blit(text_surf, (900, 325))
        if show_ans3 == True:
            text_surf = font.render(str(round(math.sqrt(2 * gravity * (length - length * math.sin(math.radians(theta2)))), 2)) + 'm/s', True, 'red')
            screen.blit(text_surf, (1100, 365))
    elif problem_type == 8:
        text_surf = font.render('2. While moving at max velocity,', True, 'black')
        screen.blit(text_surf, (900, 200))
        text_surf = font.render('what is the period of the car?', True, 'black')
        screen.blit(text_surf, (900, 225))
        if show_ans2 == True:
            text_surf = font.render(str(round((2 * math.pi * radius1) / math.sqrt(Ustatic * radius1 * gravity), 2)) + 's', True, 'red')
            screen.blit(text_surf, (1100, 265))
        text_surf = font.render('3. What is the max velocity', True, 'black')
        screen.blit(text_surf, (900, 300))
        text_surf = font.render('assuming the new conditions?', True, 'black')
        screen.blit(text_surf, (900, 325))
        if show_ans3 == True:
            text_surf = font.render(str(round(math.sqrt(radius1 * gravity * math.tan(math.radians(theta))), 2)) + 'm/s', True, 'red')
            screen.blit(text_surf, (1100, 365))
    elif problem_type == 9:
        text_surf = font.render('2. What is the distance the', True, 'black')
        screen.blit(text_surf, (900, 200))
        text_surf = font.render('blue mass travels?', True, 'black')
        screen.blit(text_surf, (900, 225))
        if show_ans2 == True:
            text_surf = font.render(str(round((mass1**2 * length * (1 - math.cos(math.radians(theta1)))) / (mass2**2 * math.sin(math.radians(theta2))), 2)) + 'm', True, 'red')
            screen.blit(text_surf, (1100, 265))
        text_surf = font.render('3. How long does it take for', True, 'black')
        screen.blit(text_surf, (900, 300))
        text_surf = font.render('the system to complete 1 cycle?', True, 'black')
        screen.blit(text_surf, (900, 325))
        if show_ans3 == True:
            text_surf = font.render(str(round(math.pi * math.sqrt(length / gravity) + (2 * mass1 * math.sqrt(2 * gravity * length * (1 - math.cos(math.radians(theta1))))) / (mass2 * gravity * math.sin(math.radians(theta2))), 2)) + 's', True, 'red')
            screen.blit(text_surf, (1100, 365))
    else:
        text_surf = font.render('2. What is the velocity of', True, 'black')
        screen.blit(text_surf, (900, 200))
        text_surf = font.render('the mass after ' + str(tfall) + ' seconds?', True, 'black')
        screen.blit(text_surf, (900, 225))
        if show_ans2 == True:
            text_surf = font.render(str(round((mass1 * gravity / b_constant) * (1 - math.exp(-b_constant * tfall / mass1)), 2)) + 'm/s', True, 'red')
            screen.blit(text_surf, (1100, 265))
        #text_surf = font.render('3. What is the total work', True, 'black')
        #screen.blit(text_surf, (900, 300))
        ###if show_ans3 == True:
            #text_surf = font.render(str(round(((mass1**3 * gravity**2) / (2 * b_constant**2)) - (mass1 * gravity * height), 2)) + 'J', True, 'red')
            #screen.blit(text_surf, (1100, 365))
        
                                                
def get_accel(mass1, mass2, mass_pulley, theta, Ustatic, Ukinetic, inertia_constant):
    if problem_type == 1:
        if inertia_slider.getValue() == 0:
            return ((mass1 - mass2) * gravity) / (mass1 + mass2)
        return ((mass1 - mass2) * gravity) / ((.5 * mass_pulley) + mass1 + mass2)
    elif problem_type == 2:
        if friction_slider.getValue() == 0:
            if inertia_slider.getValue() == 0:
                return ((mass1 * gravity) - (mass2 * gravity * math.sin(math.radians(theta)))) / (mass1 + mass2)
            return ((mass1 * gravity) - (mass2 * gravity * math.sin(math.radians(theta)))) / (.5 * mass_pulley + mass1 + mass2)
        else:
            if abs(mass1 * gravity - mass2 * gravity * math.sin(math.radians(theta))) <= Ustatic * mass2 * gravity * math.cos(math.radians(theta)):
                return 0
            else:
                if inertia_slider.getValue() == 0:
                    return (mass1 * gravity - mass2 * gravity * math.sin(math.radians(theta)) - Ukinetic * mass2 * gravity * math.cos(math.radians(theta))) / (mass2 + mass1)
                return (mass1 * gravity - mass2 * gravity * math.sin(math.radians(theta)) - Ukinetic * mass2 * gravity * math.cos(math.radians(theta))) / (.5 * mass_pulley + mass2 + mass1)
    elif problem_type == 3:
        return (gravity * math.sin(math.radians(theta))) / (1.0 + inertia_constant)
    else:
        return 0

def print_pulleyEx(displacement, theta):
    if problem_type == 1 or problem_type == 2:
        if problem_type == 1:
            center_x = 600.0
        elif problem_type == 2:
            center_x = 450.0
        center_y = 100.0
        radius = 70.0
        start_y = 370.0
        pygame.draw.circle(screen, 'black', (center_x, center_y), radius)
        w1 = 20 + (mass1 * .35)
        w2 = 20 + (mass2 * .35)
        pygame.draw.line(screen, 'black', (center_x - radius, center_y), (center_x - radius, start_y + displacement * 3))
        pygame.draw.rect(screen, 'red', (center_x - radius - (w1 / 2), start_y + displacement * 3, w1, w1))
        if problem_type == 1:
            pygame.draw.line(screen, 'black', (center_x + radius, center_y), (center_x + radius, start_y - displacement * 3))
            pygame.draw.rect(screen, 'blue', (center_x + radius - (w2/2), start_y - displacement * 3, w2, w2))
        elif problem_type == 2:
            blk2_x = int(center_x + (350 * math.cos(math.radians(theta))) - (displacement * 3 * math.cos(math.radians(theta))))
            blk2_y = int(30 + (350 * math.sin(math.radians(theta))) - (displacement * 3 * math.sin(math.radians(theta))))
            line_length = 500 - (90 - theta * 3)
            pygame.draw.line(screen, 'black', (center_x, center_y - 50), (center_x + line_length * math.cos(math.radians(theta)), center_y + line_length * math.sin(math.radians(theta)) - 50))
            pygame.draw.line(screen, 'black', (center_x, center_y - 50), (center_x, center_y + line_length * math.sin(math.radians(theta)) - 50))
            
            pygame.draw.line(screen, 'black', (int(center_x + (radius - 1) * math.sin(math.radians(theta))), int(center_y - (radius - 1) * math.cos(math.radians(theta)))), (blk2_x, blk2_y))
            pygame.draw.rect(screen, 'blue', (blk2_x, blk2_y, w2, w2))

def print_rollingEx(displacement, theta):
    top_x = 350
    top_y = 200
    line_length = 500 - (90 - theta * 3)
    pygame.draw.line(screen, 'black', (top_x, top_y), (int(top_x + line_length * math.cos(math.radians(theta))), int(top_y + line_length * math.sin(math.radians(theta)))))
    r = 25
    center_x = top_x
    center_y = top_y - r
    pygame.draw.circle(screen, 'red', (center_x + displacement * 10 * math.cos(math.radians(theta)), center_y + displacement * 10 * math.sin(math.radians(theta))), r)
            
def print_projectileEx(theta, initial_velocity, time):
    start_x = 50
    start_y = 470
    pygame.draw.line(screen, 'black', (start_x, start_y), (start_x + 800, start_y))
    r = 20
    pygame.draw.circle(screen, 'red', (int(start_x + initial_velocity * math.cos(math.radians(theta)) * time), int(start_y - r - initial_velocity * math.sin(math.radians(theta)) * time + .5 * gravity * pow(time, 2))), r)

def print_collisionEx(mass1, mass2, Ukinetic, initial_velocity, time, start_x, friction_start):
    #start_x = 100
    start_y = 420
    #friction_start = 300
    w1 = 20 + (mass1 * .35)
    w2 = 20 + (mass2 * .35)
    pygame.draw.line(screen, 'black', (start_x - w1, start_y), (friction_start, start_y))
    y = 5
    for i in range(56):
        pygame.draw.line(screen, 'black', (friction_start + (i * 10), start_y - y + 5), (friction_start + ((i + 1) * 10), start_y + y + 5))
        if y == 5:
            y = -5
        else:
            y = 5
    t1 = (friction_start - start_x) / initial_velocity
    t_total = t1 + ((mass1 * initial_velocity) / (mass2 * Ukinetic * gravity))
    if time < t1:
        pygame.draw.rect(screen, 'red', (start_x + initial_velocity * time - w1, start_y - w1, w1, w1))
        pygame.draw.rect(screen, 'blue', (friction_start, start_y - w2, w2, w2))
    elif time < t_total:
        pygame.draw.rect(screen, 'red', (friction_start - w1, start_y - w1, w1, w1))
        pygame.draw.rect(screen, 'blue', (friction_start + ((mass1 * initial_velocity * (time - t1)) / mass2) - ((Ukinetic * gravity * pow(time - t1, 2)) / 2), start_y - w2, w2, w2))
    else:
        pygame.draw.rect(screen, 'red', (friction_start - w1, start_y - w1, w1, w1))
        pygame.draw.rect(screen, 'blue', (friction_start + (1 / (2 * Ukinetic * gravity)) * pow((mass1 * initial_velocity) / mass2, 2), start_y - w2, w2, w2))

def print_circmotion(mass1, mass2, central_mass, radius1, radius2, time):
    center_x = 600
    center_y = 400
    pygame.draw.circle(screen, 'black', (center_x, center_y), int(central_mass / 250))
    ang_v1 = math.sqrt(uni_constant * central_mass / (radius1 ** 3))
    ang_v2 = math.sqrt(uni_constant * central_mass / (radius2 ** 3))
    pos_x, pos_y = int(center_x + radius2 * math.cos(ang_v2 * time)), int(center_y + radius2 * math.sin(ang_v2 * time)) 
    pygame.draw.circle(screen, 'blue', (pos_x, pos_y), int(mass2))
    pygame.draw.line(screen, 'blue', (center_x, center_y), (pos_x, pos_y))
    pos_x, pos_y = int(center_x + radius1 * math.cos(ang_v1 * time)), int(center_y + radius1 * math.sin(ang_v1 * time)) 
    pygame.draw.circle(screen, 'red', (pos_x, pos_y), int(mass1))
    pygame.draw.line(screen, 'red', (center_x, center_y), (pos_x, pos_y))
    
def print_tensionEx(theta1, theta2, length, time):
    pivot_x = 650
    pivot_y = 200
    width = 50
    box_top_x = pivot_x - length * math.cos(math.radians(theta2))
    box_top_y = pivot_y + length * math.sin(math.radians(theta2))
    if time == 0:
        pygame.draw.line(screen, 'blue', (pivot_x, pivot_y), (box_top_x, box_top_y))
        pygame.draw.rect(screen, 'black', (box_top_x - width / 2, box_top_y, width, width))
        if box_top_y - length * math.sin(math.radians(theta1)) < pivot_y:
            pygame.draw.line(screen, 'red', (box_top_x, box_top_y), (box_top_x - length * math.cos(math.radians(theta1)), pivot_y))
        else:
            pygame.draw.line(screen, 'red', (box_top_x, box_top_y), (box_top_x - length * math.cos(math.radians(theta1)), box_top_y - length * math.sin(math.radians(theta1))))
    else:
        new_theta = -1 * math.radians(90 - theta2) * math.cos((math.sqrt(gravity / length / .01)) * time)
        end_x = pivot_x + length * math.sin(new_theta)
        end_y = pivot_y + length * math.cos(new_theta)
        pygame.draw.line(screen, 'blue', (pivot_x, pivot_y), (end_x, end_y))
        pygame.draw.rect(screen, 'black', (end_x - width / 2, end_y, width, width))

def print_racecar(radius1, Ustatic, time):
    center_x = 550
    center_y = 350
    width = 30
    pygame.draw.circle(screen, 'black', (center_x, center_y), radius1, width=1)
    new_theta = (time * math.sqrt(Ustatic * radius1 * gravity) / radius1)
    car_x = center_x + radius1 * math.cos(new_theta)
    car_y = center_y + radius1 * math.sin(new_theta)
    pygame.draw.line(screen, 'black', (center_x, center_y), (car_x, car_y))
    pygame.draw.rect(screen, 'black', (car_x - width / 2, car_y - width / 2, width, width))

def print_resistive(mass1, b_constant, height, time):
    start_x = 550
    max_y = 550
    start_y = 550 - height
    r = 0.0
    if mass1 < 10:
        r = 10.0
    else:
        r = mass1 / 3
    d = (mass1 * gravity / b_constant) * time - ((mass1**2 * gravity) / b_constant**2) * (1 - math.exp((-b_constant * time) / mass1))
    if start_y + d < max_y:
        pygame.draw.circle(screen, 'red', (start_x, int(start_y + d)), r)
    else:
        pygame.draw.circle(screen, 'red', (start_x, max_y), r)

def print_bonus1(mass1, mass2, theta1, theta2, length, time):
    lin_len = 550
    pygame.draw.line(screen, 'black', (50, 550), (50 + lin_len + 10, 550))
    pygame.draw.line(screen, 'black', (50 + lin_len + 10, 550), (50 + lin_len + 15, 540))
    pygame.draw.line(screen, 'black', (50, 550), (50, 550 - lin_len * math.tan(math.radians(theta2))))
    pygame.draw.line(screen, 'black', (50 + lin_len, 550), (50, 550 - lin_len * math.tan(math.radians(theta2))))
    blue_x = 600
    blue_y = 550 - mass2
    piv_x = blue_x + mass2 + mass1
    piv_y = blue_y - length
    if time == 0:
        pygame.draw.circle(screen, 'blue', (blue_x, blue_y), mass2)
        pygame.draw.line(screen, 'black', (piv_x + length * math.sin(math.radians(theta1)), piv_y + length * math.cos(math.radians(theta1))), (piv_x, piv_y))
        pygame.draw.circle(screen, 'red', (piv_x + length * math.sin(math.radians(theta1)), piv_y + length * math.cos(math.radians(theta1))), mass1)
    elif time < math.pi / 2 * math.sqrt(length / gravity):
        new_theta = math.radians(theta1) * math.cos(math.sqrt(gravity / length) * time)
        pygame.draw.circle(screen, 'blue', (blue_x, blue_y), mass2)
        pygame.draw.line(screen, 'black', ((int(piv_x + length * math.sin(new_theta))), int(piv_y + length * math.cos(new_theta))), (piv_x, piv_y))
        pygame.draw.circle(screen, 'red', (int(piv_x + length * math.sin(new_theta)), int(piv_y + length * math.cos(new_theta))), mass1)
    elif time < (math.pi / 2 * math.sqrt(length / gravity)) + ((2 * mass1 * math.sqrt(2 * gravity * length * (1 - math.cos(math.radians(theta1))))) / (mass2 * gravity * math.sin(math.radians(theta2)))):
        pygame.draw.line(screen, 'black', (piv_x, piv_y), (piv_x, piv_y + length))
        pygame.draw.circle(screen, 'red', (piv_x, piv_y + length), mass1)
        v = (mass1 * math.sqrt(2 * gravity * length * (1 - math.cos(math.radians(theta1))))) / mass2
        theta2_rad = math.radians(theta2)
        t_time = time - (math.pi / 2 * math.sqrt(length / gravity))
        d = v * t_time - .5 * gravity * math.sin(theta2_rad) * t_time**2
        new_x = blue_x - d * math.cos(theta2_rad)
        new_y = blue_y - d * math.sin(theta2_rad)
        pygame.draw.circle(screen, 'blue', (new_x, new_y), mass2)
    elif time < (math.pi * math.sqrt(length / gravity)) + ((2 * mass1 * math.sqrt(2 * gravity * length * (1 - math.cos(math.radians(theta1))))) / (mass2 * gravity * math.sin(math.radians(theta2)))):
    #else:       
        t_delay = (math.pi / 2 * math.sqrt(length / gravity)) + ((2 * mass1 * math.sqrt(2 * gravity * length * (1 - math.cos(math.radians(theta1))))) / (mass2 * gravity * math.sin(math.radians(theta2))))
        new_theta = math.radians(theta1) * math.sin(math.sqrt(gravity / length) * (time - t_delay))
        pygame.draw.circle(screen, 'blue', (blue_x, blue_y), mass2)
        pygame.draw.line(screen, 'black', ((int(piv_x + length * math.sin(new_theta))), int(piv_y + length * math.cos(new_theta))), (piv_x, piv_y))
        pygame.draw.circle(screen, 'red', (int(piv_x + length * math.sin(new_theta)), int(piv_y + length * math.cos(new_theta))), mass1)
    #else:
        #time = time % (math.pi * math.sqrt(length / gravity)) + ((2 * mass1 * math.sqrt(2 * gravity * length * (1 - math.cos(math.radians(theta1))))) / (mass2 * gravity * math.sin(math.radians(theta2))))
randomize()
acceleration = 0.0
displacement = 0.0
time = 0.0
frames = 0
start_x = 100
friction_start = 300

async def main():
    global running, acceleration, hvar, Vvar, frames, time, displacement, menu, tvar, mass1, mass2, mass_pulley, radius_pulley, show_ans1, show_ans2, show_ans3, theta, problem_type, Ustatic, Ukinetic, inertia_constant, initial_velocity, central_mass, radius1, radius2, tension1, tension2, theta1, theta2, length, height, b_constant, tfall
    while running:
        clock.tick(60)
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                running = False
        screen.fill("white")
        acceleration = get_accel(mass1, mass2, mass_pulley, theta, Ustatic, Ukinetic, inertia_constant)
        hvar = .5 * acceleration * pow(tvar, 2)
        Vvar = acceleration * tvar

        if problem_type == 1 or problem_type == 2:
            inertia_output.setText(inertia_slider.getValue())
        if problem_type == 2:
            friction_output.setText(friction_slider.getValue())
        
        if menu == True:
            if problem_type == 1:
                inertia_slider.show()
                inertia_slider.enable()
                inertia_output.show()
                inertia_output.enable()
                friction_slider.hide()
                friction_output.hide()
            elif problem_type == 2:
                inertia_slider.show()
                inertia_slider.enable()
                inertia_output.show()
                inertia_output.enable()
                friction_slider.show()
                friction_slider.enable()
                friction_output.show()
                friction_output.enable()
            elif problem_type in {3, 4, 5, 6, 7, 8, 9, 10}:
                inertia_slider.hide()
                inertia_output.hide()
                friction_slider.hide()
                friction_output.hide()
            frames = 0
            time = 0.0
            #displacement = 0.0
        else:
            inertia_slider.disable()
            friction_slider.disable()
            if problem_type == 4:
                tvar = 2.0 * initial_velocity * math.sin(math.radians(theta)) / gravity
            elif problem_type == 5:
                tvar = ((friction_start - start_x) / initial_velocity) + ((mass1 * initial_velocity) / (mass2 * Ukinetic * gravity))
                #tvar = 100
            if time < tvar or (problem_type in {6, 7, 8, 9, 10} and menu == False and time < 100.0):
                frames += 1
                time = float(frames) / 60.0
                displacement = .5 * acceleration * pow(time, 2)
            else:
                menu = True


        
        if problem_type == 1 or problem_type == 2:
            print_pulleyEx(displacement, theta)
        elif problem_type == 3:
            print_rollingEx(displacement, theta)
        elif problem_type == 4:
            print_projectileEx(theta, initial_velocity, time)
        elif problem_type == 5:
            print_collisionEx(mass1, mass2, Ukinetic, initial_velocity, time * 5, start_x, friction_start)
        elif problem_type == 6:
            print_circmotion(mass1, mass2, central_mass, radius1, radius2, time * 1000000)
        elif problem_type == 7:
            print_tensionEx(theta1, theta2, length * 10, time)
        elif problem_type == 8:
            print_racecar(radius1, Ustatic, time)
        elif problem_type == 9:
            total = math.pi * math.sqrt(length / gravity) + (2 * mass1 * math.sqrt(2 * gravity * length * (1 - math.cos(math.radians(theta1))))) / (mass2 * gravity * math.sin(math.radians(theta2)))
            print_bonus1(mass1, mass2, theta1, theta2, length, (time * 5) % total)
        else:
            print_resistive(mass1, b_constant, height, time * 1)

        text_print()

        pygame_widgets.update(events)
        pygame.display.update()
        await asyncio.sleep(0)
    pygame.quit()

asyncio.run(main())